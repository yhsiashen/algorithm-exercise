CREATE PROCEDURE `test2`(IN `v_seckill_id` BIGINT(20), OUT `r_result` INT(11))
  BEGIN
    DECLARE count INT DEFAULT 0;
    START TRANSACTION ;
    INSERT IGNORE into success_killed (seckill_id, user_phone, create_time, state)
      VALUES (v_seckill_id,null,null,null);
    SELECT row_count() into count;
    IF (count=0) THEN
      ROLLBACK ;
      set r_result=-1;
      ELSE
      COMMIT ;
      END IF ;
  END